package key_builder;

public class KeyManeger {
    public static byte[] generateKey(int length) {
        byte[] keyString = new byte[length];
        keyString = generate(length);
        return keyString;
    }

    private static byte[] generate(int length) {
        byte[] key_Digit = new byte[length];    //生成随机数字0——9密钥串
        byte[] key_Char = new byte[length];     //生成随机字符串a——z,A——Z
        byte[] resultKey = new byte[length];    //通过随机数，从上面的两个随机字符池取得字符，组成密码
        int i;
        for(i = 0; i < length; ++i) {
            key_Digit [i] =("" + (Math.random() * 9.0D + 1.0D)).getBytes()[0];            //从0——9中选取一个数字填入到数字密钥池
            if (Math.random() * 10000<5000) {                                             //如果随机数小于5000则从A——Z中选字符，反之则从a——z中选择
                key_Char[i] = ("" + (char)((int)(Math.random() * 26 + 65))).getBytes()[0];//从A——Z中选取一个字符填入到字符密钥池
            } else {
                key_Char[i] = ("" + (char)((int)(Math.random() * 26 + 97))).getBytes()[0];//从a——z中选取一个字符填入到字符密钥池
            }
        }
        for(i = 0; i < length; ++i) {
            if (Math.random() * 10000<5000) {
                resultKey[i] = key_Digit[i];    //从数字密钥池选择字符填入密钥结果池
            } else {
                resultKey[i] = key_Char[i];     //从字符密钥池选择字符填入密钥结果池
            }
        }

        return resultKey;
    }
}
