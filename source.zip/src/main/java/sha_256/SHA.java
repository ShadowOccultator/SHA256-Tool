package sha_256;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class SHA {
    public static void main(String[] args) {
        sha_256_ToBinarray("12".getBytes(StandardCharsets.UTF_8));
    }
    public static String sha_256(byte []source){
        MessageDigest instance = null;
        try {
            instance = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        String result="";
        instance.update(source);
        byte [] b=new byte[16];
        b= instance.digest();
        for (byte bin:
             b) {
            result+=String.format("%02x",new Integer(bin&0xFF));
        }
        return result;
    }
    public static byte[] sha_256_ToBinarray(byte []source){
        MessageDigest instance = null;
        try {
            instance = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        instance.update(source);
        byte [] b;
        b= instance.digest();
        return b;
    }
}
