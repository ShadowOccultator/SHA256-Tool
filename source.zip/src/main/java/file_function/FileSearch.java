package file_function;

import java.io.File;
import java.util.ArrayList;

public class FileSearch {
    private ArrayList<ArrayList<String>> array = new ArrayList();

    public FileSearch() {
    }

    public ArrayList<ArrayList<String>> printFilePath(String path) {
        this.printFileName(new File(path));
        return this.array;
    }

    private void printFileName(File f) {
        ArrayList<String> a=new ArrayList<>();
        if (f.isDirectory()) {
            File[] arrayFile = f.listFiles();
            if (arrayFile != null) {
                for(int i = 0; i < arrayFile.length; ++i) {
                    File file1 = arrayFile[i];
                    this.printFileName(file1);
                }
            }
        } else {
            a.add(f.getAbsolutePath());
        }
        this.array.add(a);
    }
}
