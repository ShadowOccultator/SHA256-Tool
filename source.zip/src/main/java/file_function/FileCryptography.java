package file_function;

import org.jetbrains.annotations.Contract;
import sha_256.SHA;
import java.io.*;
import java.nio.charset.StandardCharsets;

/**
 * 设置.cry文件为加密文件后缀名
 * 设置了一个文件头start以便验证文件类型
 */
public class FileCryptography {
    private static final byte[] fileHead ={18,-12,67,99,12,34,11,3,77};                        //设置一个文件头作为.cry加密文件验证的唯一方式
    private static final byte headLength =0x9;
    public static boolean fileCryptography(String originPath,String cryPath,byte[] key){   //由提供的源地址与加密处理后的地址借助密钥生成加密文件
        File originFile=new File(originPath);
        File cryFile=new File(cryPath);                                                    //尝试创建加密文件.cry结尾
        try {
            cryFile.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("文件已经存在");
        }
        if(isExistsFile(originFile)&&isExistsFile(cryFile))                                //如果源文件与加密文件都存在，执行加密操作
            fileCryptography(originFile,cryFile,key);
        return false;
    }
    public static boolean brokerFileCryptography(String originPath,byte[] key){             //Dangerous!!!!!由源地址进行加密，并且取代源文件
        File originFile=new File(originPath);
        File cryFile=new File(newPath(originPath));
        try {
            cryFile.createNewFile();                                                        //尝试创建加密文件.cry结尾
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("文件已经存在");
        }
        boolean result=false;
        if(isExistsFile(originFile)&&isExistsFile(cryFile))   {                              //如果源文件与加密文件都存在，执行加密操作
            result=fileCryptography(originFile,cryFile,key);
        }
        return result;
    }
    private static boolean fileCryptography(File originFile,File cryFile,byte[] key){
        if(!(writeFile(cryFile, fileHead,false)&&writeFile(cryFile, SHA.sha_256_ToBinarray(key),true))){//将验证信息写入文件头(包括文件头head和密码的hash值)
            return false;
        }
        FileInputStream fis=null;
        FileOutputStream fos=null;
        try {
            byte [] b=new byte[8*1024];
            fis=new FileInputStream(originFile);
            fos=new FileOutputStream(cryFile,true);
            int count=0;
            int flag=0;                                                                     //记录下密钥数组被引用时的下标，防止密钥未被使用全部长度后重新使用
            while((count=fis.read(b))!=-1){                                                 //边读取边加密
                for(int i=flag,j=0;j<b.length;j++){
                   b[j]= (byte) (b[j]^key[i]);
                    flag=i;
                   if(i==key.length-1){                                                     //如果密钥使用完毕，将指向位置置零
                       flag=0;
                       i=flag;
                   }else
                       i++;

                }
                fos.write(b,0,count);                                                   //加密完b的所有元素就写入，接着读下一个b
                fos.flush();
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }finally {//加密完成后删除源文件
            try {
                fis.close();
                fos.close();
                originFile.delete();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return false;
    }
    public static boolean fileDecrypt(String cryPath,String key){
        if(cryPath.endsWith(".cry"))
        return fileDecrypt(new File(cryPath),new File(originPath(cryPath)),key.getBytes(StandardCharsets.UTF_8));
        else{
            System.err.println("File format is error");
            return false;
        }
    }
    public static boolean fileDecrypt(File cryFile,File originFile,byte[] key){
        try {                                                                               //尝试解密
            originFile.createNewFile();                                                     //创建源文件
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(!judgeStart(cryFile))                                                            //判断文件头是否是head
            return false;
        FileInputStream fis=null;
        FileOutputStream fos=null;
        try {
            byte [] b=new byte[8*1024];
            fis=new FileInputStream(cryFile);
            fos=new FileOutputStream(originFile,true);                              //设置文件写入模式为追加
            int count=0;
            int flag=0;
            fis.read(new byte[9]);
            byte[] hex=new byte[32];                                                        //读出hash值进行判断
            fis.read(hex);
            if(hex.length!= SHA.sha_256_ToBinarray(key).length){                             //判断hash是否为伪造
                System.out.println("mistake");
                return false;
            }
            byte [] hex_key= SHA.sha_256_ToBinarray(key);                                    //与密码hash进行比较
            for(int i=0;i<hex.length;i++){
                if(hex[i]!=hex_key[i]){
                    System.out.println("hex is error");
                    return false;
                }
            }
            while((count=fis.read(b))!=-1){                                                 //边读边解密
                for(int i=flag,j=0;j<b.length;j++){
                    b[j]= (byte) (b[j]^key[i]);
                    flag=i;
                    if(i==key.length-1){
                        flag=0;
                        i=flag;
                    }else
                        i++;
                }
                fos.write(b,0,count);
                fos.flush();
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                fis.close();
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
    private static boolean isExistsFile(File f){
        if(f.exists()&&f.isFile())
            return true;
        return false;
    }
    private static boolean writeFile(File f,byte[] b,boolean append){
        FileOutputStream fos=null;
        try {
            fos=new FileOutputStream(f,append);
            fos.write(b);
            fos.flush();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private static String newPath(String originPath){
        return originPath+".cry";
    }
    public static String originPath(String cryPath){
        if(cryPath.endsWith(".cry"))
            return cryPath.substring(0,cryPath.length()-4);
        else
            return null;
    }
    private static boolean judgeStart(File f){
        FileInputStream fis=null;
        try {
           fis =new FileInputStream(f);
           byte[] b=new byte[headLength];
           fis.read(b);
           fis.close();
            for (int i = 0; i <b.length; i++) {
                if((b[i]!= fileHead[i]))
                    return false;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }
}
