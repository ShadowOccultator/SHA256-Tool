import file_function.FileCryptography;
import key_builder.KeyManeger;
import org.apache.commons.cli.*;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Run {
    public static void main(String[] args) {
        Options option=new Options()
                .addOption("help",false,"help you know command")
                .addOption("cry",true,"cryptography a file")
                .addOption("decry",true,"decrypt your file")
                .addOption("key",true,"The key for your cryptographic file");
        CommandLineParser parser=new DefaultParser();
        CommandLine commandLine=null;
        new HelpFormatter().printHelp("SHA256_tool",option);
        String[] commArgs=new Scanner(System.in).nextLine().split(" ");
        try {
             commandLine=parser.parse(option,commArgs);
        if(commandLine==null){
            System.err.println("CODE IS NO INSERT");
            System.exit(-1);
        }else{
            String code=null;
            String path=null;
            if(commandLine.hasOption("help")){
                HelpFormatter hf = new HelpFormatter();
                hf.printHelp("", option);
            }
            else if(commandLine.hasOption("cry")){
                byte[] key=KeyManeger.generateKey(16);
                path=commandLine.getOptionValue("cry");
                if(FileCryptography.brokerFileCryptography(path,key)){
                    System.out.println("Complete!"+"your key is:"+new String(key));
                }else{
                    System.err.println("A ERROR PRINT FOR APPLICATION");
                    System.exit(-1);
                }
            }
            else if(commandLine.hasOption("decry")){
                path=commandLine.getOptionValue("decry");
                code=commandLine.getOptionValue("key");
                if(FileCryptography.fileDecrypt(path,code)){
                    System.out.println("Complete!"+"your file is decrypt");
                }else{
                    System.err.println("A ERROR PRINT FOR APPLICATION");
                    System.exit(-1);
                }
            }else{
                System.err.println("CODE IS NO INSERT");
                System.exit(-1);
            }
        }
        } catch (ParseException e) {
            System.err.println("CODE NO SUCH");
            System.exit(-1);
        }
    //-decry C:\Users\YYDS\Desktop\第三章作业1.doc -key Gm236x473xnG6v16
    }
}
